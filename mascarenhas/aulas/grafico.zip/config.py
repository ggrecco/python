#todo tipo de parametro de configuração

class Configuration(object):
    DEBUG = True
